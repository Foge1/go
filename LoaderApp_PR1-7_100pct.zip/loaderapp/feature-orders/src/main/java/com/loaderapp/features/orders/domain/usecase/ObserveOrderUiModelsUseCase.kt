package com.loaderapp.features.orders.domain.usecase

import com.loaderapp.features.orders.domain.Order
import com.loaderapp.features.orders.domain.OrderActions
import com.loaderapp.features.orders.domain.OrderAssignmentStatus
import com.loaderapp.features.orders.domain.OrderRulesContext
import com.loaderapp.features.orders.domain.OrderStateMachine
import com.loaderapp.features.orders.domain.Role
import com.loaderapp.features.orders.domain.model.OrderDetail
import com.loaderapp.features.orders.domain.orders.filterForUser
import com.loaderapp.features.orders.domain.repository.OrdersRepository
import com.loaderapp.features.orders.domain.session.CurrentUser
import com.loaderapp.features.orders.domain.session.CurrentUserProvider
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.mapLatest
import javax.inject.Inject

/**
 * Единая точка построения domain-моделей деталей заказа из потоков пользователя и заказов.
 */
class ObserveOrderUiModelsUseCase
    @Inject
    constructor(
        private val repository: OrdersRepository,
        private val currentUserProvider: CurrentUserProvider,
        private val stateMachine: OrderStateMachine,
    ) {
        operator fun invoke(): Flow<ObserveOrderUiModelsResult> =
            combine(
                currentUserProvider.observeCurrentUser(),
                repository.observeOrders(),
            ) { actor, orders ->
                actor to orders
            }.mapLatest { (actor, orders) ->
                if (actor == null) {
                    ObserveOrderUiModelsResult.NotSelected
                } else {
                    val visibleOrders = orders.filterForUser(actor)
                    val baseContext = buildBaseContext(actor)
                    ObserveOrderUiModelsResult.Selected(
                        visibleOrders.map { order: Order -> order.toOrderDetail(actor, baseContext) },
                    )
                }
            }

        private suspend fun buildBaseContext(actor: CurrentUser): OrderRulesContext =
            when (actor.role) {
                Role.LOADER ->
                    OrderRulesContext(
                        activeAssignmentExists = repository.hasActiveAssignment(actor.id),
                        activeApplicationsForLimitCount = repository.countActiveApplicationsForLimit(actor.id),
                        loaderHasActiveAssignmentInThisOrder = false,
                    )
                Role.DISPATCHER -> OrderRulesContext()
            }

        private fun Order.toOrderDetail(
            actor: CurrentUser,
            baseContext: OrderRulesContext,
        ): OrderDetail {
            val hasAssignmentHere =
                actor.role == Role.LOADER &&
                    assignments.any { it.loaderId == actor.id && it.status == OrderAssignmentStatus.ACTIVE }

            val context = baseContext.copy(loaderHasActiveAssignmentInThisOrder = hasAssignmentHere)
            val actions: OrderActions = stateMachine.actionsFor(this, actor, context)

            return OrderDetail(
                order = this,
                currentUserId = actor.id,
                currentUserRole = actor.role,
                canApply = actions.canApply,
                applyBlockReason = actions.applyDisabledReason,
                canWithdraw = actions.canWithdraw,
                withdrawBlockReason = actions.withdrawDisabledReason,
                canSelect = actions.canSelect,
                canUnselect = actions.canUnselect,
                canStart = actions.canStart,
                startBlockReason = actions.startDisabledReason,
                canCancel = actions.canCancel,
                cancelBlockReason = actions.cancelDisabledReason,
                canComplete = actions.canComplete,
                completeBlockReason = actions.completeDisabledReason,
                canOpenChat = actions.canOpenChat,
            )
        }
    }

sealed interface ObserveOrderUiModelsResult {
    data object NotSelected : ObserveOrderUiModelsResult

    data class Selected(
        val orders: List<OrderDetail>,
    ) : ObserveOrderUiModelsResult
}
