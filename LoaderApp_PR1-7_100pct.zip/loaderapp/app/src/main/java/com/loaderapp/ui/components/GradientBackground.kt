package com.loaderapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Gradient start/end per design spec B.7
private val GradientStart = Color(0xFF0F2227)
private val GradientEnd = Color(0xFF0F1416)

/**
 * Full-screen vertical gradient background per design spec.
 * Uses hardcoded spec colours (0xFF0F2227 → 0xFF0F1416) as required.
 * Apply at screen root; never inside cards or composites.
 */
@Composable
fun GradientBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier =
            modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(GradientStart, GradientEnd))),
        content = content,
    )
}

/**
 * Modifier extension for scroll containers.
 * endY = POSITIVE_INFINITY stretches the gradient along the full scroll content
 * height so no hard colour boundary appears mid-scroll.
 *
 * IMPORTANT: apply this modifier BEFORE verticalScroll so the background is
 * drawn beneath the content layer, not on top of it.
 */
@Composable
fun Modifier.scrollableGradientBackground(): Modifier =
    this.background(
        Brush.verticalGradient(
            colors = listOf(GradientStart, GradientEnd),
            endY = Float.POSITIVE_INFINITY,
        ),
    )
