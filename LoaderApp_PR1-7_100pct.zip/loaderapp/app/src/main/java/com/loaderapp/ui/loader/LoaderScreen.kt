package com.loaderapp.ui.loader

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.WorkOff
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import com.loaderapp.core.ui.theme.AppColors
import com.loaderapp.core.ui.theme.AppSpacing
import com.loaderapp.core.ui.theme.ShapeButton
import com.loaderapp.core.ui.theme.ShapeChip
import com.loaderapp.features.orders.domain.OrderApplicationStatus
import com.loaderapp.features.orders.presentation.DispatcherHistoryUiState
import com.loaderapp.features.orders.presentation.OrderUiModel
import com.loaderapp.features.orders.presentation.OrdersTab
import com.loaderapp.features.orders.presentation.OrdersUiState
import com.loaderapp.features.orders.presentation.OrdersViewModel
import com.loaderapp.features.orders.presentation.mapper.toLegacyOrderModel
import com.loaderapp.ui.components.EmptyStateView
import com.loaderapp.ui.components.FadingEdgeLazyColumn
import com.loaderapp.ui.components.GradientBackground
import com.loaderapp.ui.components.HistoryScreen
import com.loaderapp.ui.components.LoadingView
import com.loaderapp.ui.components.OrderCard
import com.loaderapp.ui.components.OrdersScreenHeader
import com.loaderapp.ui.components.OrdersScreenRole
import com.loaderapp.ui.components.OrdersSegmentedTabs
import com.loaderapp.ui.components.OrdersTabCounts
import com.loaderapp.ui.components.StatsBar
import com.loaderapp.ui.components.toStatsBarUiModel
import com.loaderapp.ui.main.LocalBottomNavHeight

// ── Layout constants — all via AppSpacing tokens ─────────────────────────────

private object LoaderScreenDefaults {
    // 80dp: xxxl(32) + xxl(24) + xxl(24) = 80dp
    val ListBottomPadding = AppSpacing.xxxl + AppSpacing.xxl + AppSpacing.xxl
    val HistoryBottomPadding = AppSpacing.xxxl + AppSpacing.xxl + AppSpacing.xxl
    val SnackbarBottomPadding = AppSpacing.sm
    val ListHorizontalPadding = AppSpacing.lg
    val ListTopPadding = AppSpacing.md
    val ListItemSpacing = AppSpacing.md
    val FadeHeight = AppSpacing.xxxl + AppSpacing.xs // 36dp
    val StatsBarHorizontalPadding = AppSpacing.lg
    val HeaderSpacing = AppSpacing.md
    val RoleLabelHorizontalPadding = AppSpacing.lg
}

@Composable
fun LoaderScreen(
    viewModel: OrdersViewModel,
    onOrderClick: (Long) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collect { snackbarHostState.showSnackbar(it) }
    }

    var selectedTab by rememberSaveable { mutableStateOf(OrdersTab.Available) }
    val bottomNavHeight = LocalBottomNavHeight.current

    GradientBackground {
        Box(modifier = Modifier.fillMaxSize()) {
            if (state.loading) {
                LoadingView()
            } else {
                LoaderScreenContent(
                    state = state,
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it },
                    bottomNavHeight = bottomNavHeight,
                    onOrderClick = onOrderClick,
                    onApplyClicked = viewModel::onApplyClicked,
                    onWithdrawClicked = viewModel::onWithdrawClicked,
                    onCancelClicked = viewModel::onCancelClicked,
                    onHistoryQueryChanged = viewModel::onHistoryQueryChanged,
                )
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        bottom = bottomNavHeight + LoaderScreenDefaults.SnackbarBottomPadding,
                    ),
            )
        }
    }
}

@Composable
private fun LoaderScreenContent(
    state: OrdersUiState,
    selectedTab: OrdersTab,
    onTabSelected: (OrdersTab) -> Unit,
    bottomNavHeight: Dp,
    onOrderClick: (Long) -> Unit,
    onApplyClicked: (Long) -> Unit,
    onWithdrawClicked: (Long) -> Unit,
    onCancelClicked: (Long) -> Unit,
    onHistoryQueryChanged: (String) -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        OrdersScreenHeader(
            title = "Заказы",
            subtitle = "Лента заказов",
            role = OrdersScreenRole.Loader,
        )
        Spacer(modifier = Modifier.height(LoaderScreenDefaults.HeaderSpacing))
        RoleContextLabel(label = "Грузчик")
        Spacer(modifier = Modifier.height(LoaderScreenDefaults.HeaderSpacing))
        StatsBar(
            stats = state.toStatsBarUiModel(),
            modifier = Modifier.padding(
                horizontal = LoaderScreenDefaults.StatsBarHorizontalPadding,
            ),
        )
        Spacer(modifier = Modifier.height(LoaderScreenDefaults.HeaderSpacing))
        LoaderOrdersTabsContent(
            state = state,
            selectedTab = selectedTab,
            onTabSelected = onTabSelected,
            bottomNavHeight = bottomNavHeight,
            onOrderClick = onOrderClick,
            onApplyClicked = onApplyClicked,
            onWithdrawClicked = onWithdrawClicked,
            onCancelClicked = onCancelClicked,
            onHistoryQueryChanged = onHistoryQueryChanged,
        )
    }
}

@Composable
private fun LoaderOrdersTabsContent(
    state: OrdersUiState,
    selectedTab: OrdersTab,
    onTabSelected: (OrdersTab) -> Unit,
    bottomNavHeight: Dp,
    onOrderClick: (Long) -> Unit,
    onApplyClicked: (Long) -> Unit,
    onWithdrawClicked: (Long) -> Unit,
    onCancelClicked: (Long) -> Unit,
    onHistoryQueryChanged: (String) -> Unit,
) {
    OrdersSegmentedTabs(
        selected = selectedTab,
        onSelect = onTabSelected,
        counts = OrdersTabCounts(
            available = state.availableOrders.size,
            inProgress = state.inProgressOrders.size,
            history = state.historyOrders.size,
        ),
        modifier = Modifier.fillMaxSize(),
    ) { page ->
        when (page) {
            0 -> OrdersListPage(
                orders = state.availableOrders,
                bottomNavHeight = bottomNavHeight,
                emptyTitle = "Нет доступных заказов",
                emptyMessage = "Обновите страницу позже",
                emptyIcon = Icons.Default.SearchOff,
                pendingActions = state.pendingActions,
                onOrderClick = onOrderClick,
                actionSlot = { order ->
                    LoaderAvailableActions(
                        order = order,
                        pending = state.pendingActions.contains(order.order.id),
                        onApply = { onApplyClicked(order.order.id) },
                        onWithdraw = { onWithdrawClicked(order.order.id) },
                    )
                },
            )
            1 -> OrdersListPage(
                orders = state.inProgressOrders,
                bottomNavHeight = bottomNavHeight,
                emptyTitle = "Нет заказов в работе",
                emptyMessage = "Активные заказы появятся здесь",
                emptyIcon = Icons.Default.WorkOff,
                pendingActions = state.pendingActions,
                onOrderClick = onOrderClick,
                actionSlot = { order ->
                    if (order.canCancel) {
                        CancelOutlinedButton(
                            pending = state.pendingActions.contains(order.order.id),
                            onClick = { onCancelClicked(order.order.id) },
                        )
                    }
                },
            )
            2 -> LoaderHistoryPage(
                historyState = state.history,
                onHistoryQueryChanged = onHistoryQueryChanged,
                bottomNavHeight = bottomNavHeight,
                onOrderClick = onOrderClick,
            )
        }
    }
}

// ── Role context label ────────────────────────────────────────────────────────

/**
 * Display-only лейбл текущей роли.
 * Заглушка на месте будущего RoleSelector (спек B.7) — удаляется в одну строку.
 */
@Composable
private fun RoleContextLabel(label: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = LoaderScreenDefaults.RoleLabelHorizontalPadding),
        shape = ShapeChip,
        color = AppColors.Surface,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = AppColors.MutedForeground,
            modifier = Modifier.padding(
                horizontal = AppSpacing.md,
                vertical = AppSpacing.sm,
            ),
        )
    }
}

// ── Available-tab action area ─────────────────────────────────────────────────

/**
 * CTA для карточки в статусе STAFFING (вкладка «Доступны»).
 *
 * Три состояния по [OrderUiModel.myApplicationStatus]:
 * - null / WITHDRAWN / REJECTED → «Отозваться»
 * - APPLIED → «Отозвать отклик»
 * - SELECTED → бейдж «Вы отобраны» + опциональный «Отозвать»
 *
 * Вся логика прав — через [OrderUiModel], никаких прямых проверок статуса.
 */
@Composable
private fun LoaderAvailableActions(
    order: OrderUiModel,
    pending: Boolean,
    onApply: () -> Unit,
    onWithdraw: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        when (order.myApplicationStatus) {
            OrderApplicationStatus.SELECTED -> {
                SelectedBadge()
                if (order.canWithdraw) {
                    Spacer(Modifier.height(AppSpacing.sm))
                    WithdrawButton(
                        pending = pending,
                        disabledReason = null,
                        onClick = onWithdraw,
                    )
                }
            }
            OrderApplicationStatus.APPLIED -> {
                WithdrawButton(
                    pending = pending,
                    disabledReason = if (!order.canWithdraw) order.withdrawDisabledReason else null,
                    onClick = onWithdraw,
                )
            }
            else -> {
                ApplyButton(
                    pending = pending,
                    enabled = order.canApply,
                    disabledReason = order.applyDisabledReason,
                    onClick = onApply,
                )
            }
        }
    }
}

// ── Button / badge atoms ──────────────────────────────────────────────────────

@Composable
private fun ApplyButton(
    pending: Boolean,
    enabled: Boolean,
    disabledReason: String?,
    onClick: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Button(
            onClick = onClick,
            enabled = enabled && !pending,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Icon(
                imageVector = Icons.Rounded.PersonAdd,
                contentDescription = null,
                modifier = Modifier.size(AppSpacing.lg),
            )
            Spacer(Modifier.width(AppSpacing.sm))
            Text(if (pending) "Подождите..." else "Отозваться")
        }
        if (!enabled && !pending && disabledReason != null) {
            Spacer(Modifier.height(AppSpacing.sm))
            DisabledReasonHint(disabledReason)
        }
    }
}

@Composable
private fun WithdrawButton(
    pending: Boolean,
    disabledReason: String?,
    onClick: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = onClick,
            enabled = disabledReason == null && !pending,
            modifier = Modifier.fillMaxWidth(),
            shape = ShapeButton,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = AppColors.Destructive,
            ),
        ) {
            Icon(
                imageVector = Icons.Outlined.Cancel,
                contentDescription = null,
                modifier = Modifier.size(AppSpacing.lg),
            )
            Spacer(Modifier.width(AppSpacing.sm))
            Text(if (pending) "Подождите..." else "Отозвать отклик")
        }
        if (disabledReason != null && !pending) {
            Spacer(Modifier.height(AppSpacing.sm))
            DisabledReasonHint(disabledReason)
        }
    }
}

@Composable
private fun CancelOutlinedButton(
    pending: Boolean,
    onClick: () -> Unit,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = !pending,
        modifier = Modifier.fillMaxWidth(),
        shape = ShapeButton,
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = AppColors.Destructive,
        ),
    ) {
        Text(if (pending) "Подождите..." else "Отменить")
    }
}

@Composable
private fun SelectedBadge() {
    Surface(
        color = AppColors.PrimaryContainer,
        shape = ShapeChip,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = AppSpacing.md,
                vertical = AppSpacing.sm,
            ),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                modifier = Modifier.size(AppSpacing.lg),
                tint = AppColors.OnPrimary,
            )
            Spacer(Modifier.width(AppSpacing.sm))
            Text(
                text = "Вы отобраны",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                ),
                color = AppColors.OnPrimary,
            )
        }
    }
}

@Composable
private fun DisabledReasonHint(reason: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Outlined.Info,
            contentDescription = null,
            modifier = Modifier.size(AppSpacing.md),
            tint = AppColors.MutedForeground,
        )
        Spacer(Modifier.width(AppSpacing.xs))
        Text(
            text = reason,
            style = MaterialTheme.typography.bodySmall,
            color = AppColors.MutedForeground,
            textAlign = TextAlign.Start,
        )
    }
}

// ── History page ──────────────────────────────────────────────────────────────

@Composable
private fun LoaderHistoryPage(
    historyState: DispatcherHistoryUiState,
    onHistoryQueryChanged: (String) -> Unit,
    bottomNavHeight: Dp,
    onOrderClick: (Long) -> Unit,
) {
    HistoryScreen(
        state = historyState,
        onQueryChange = onHistoryQueryChanged,
        onOrderClick = onOrderClick,
        bottomPadding = bottomNavHeight + LoaderScreenDefaults.HistoryBottomPadding,
    )
}

// ── Shared list scaffold ──────────────────────────────────────────────────────

@Composable
private fun OrdersListPage(
    orders: List<OrderUiModel>,
    bottomNavHeight: Dp,
    emptyTitle: String,
    emptyMessage: String,
    emptyIcon: androidx.compose.ui.graphics.vector.ImageVector,
    pendingActions: Set<Long>,
    onOrderClick: (Long) -> Unit,
    actionSlot: @Composable (OrderUiModel) -> Unit,
) {
    if (orders.isEmpty()) {
        EmptyStateView(icon = emptyIcon, title = emptyTitle, message = emptyMessage)
        return
    }

    FadingEdgeLazyColumn(
        modifier = Modifier.fillMaxSize(),
        bottomFadeHeight = LoaderScreenDefaults.FadeHeight,
        contentPadding = PaddingValues(
            start = LoaderScreenDefaults.ListHorizontalPadding,
            end = LoaderScreenDefaults.ListHorizontalPadding,
            top = LoaderScreenDefaults.ListTopPadding,
            bottom = bottomNavHeight + LoaderScreenDefaults.ListBottomPadding,
        ),
    ) {
        items(orders, key = { it.order.id }) { order ->
            val pending = pendingActions.contains(order.order.id)
            OrderCard(
                order = order.toLegacyOrderModel(),
                onClick = { onOrderClick(order.order.id) },
                enabled = !pending,
                actionContent = { actionSlot(order) },
            )
            Spacer(Modifier.height(LoaderScreenDefaults.ListItemSpacing))
        }
    }
}
